<?php
if(!defined('DOKU_INC')) die();

/**
 * Interfejs Administracyjny (opcjonalny interfejs "stacji roboczej" Agenta)
 */
class admin_plugin_aiarticleagent extends DokuWiki_Admin_Plugin {

    public function getMenuSort() { return 100; }
    public function getMenuText($language) { return $this->getLang('menu'); }

    public function handle() {
        // Obsługa formularza z admin_plugin
        global $INPUT;
        if($INPUT->post->has('ai_agent_prompt') && checkSecurityToken()){
            $prompt = $INPUT->post->str('ai_agent_prompt');
            try {
                $helper = plugin_load('helper', 'aiarticleagent');
                if ($helper) {
                    $this->result = $helper->generateArticle($prompt);
                } else {
                    $this->result = "Błąd: Nie można załadować helpera.";
                }
            } catch (Exception $e) {
                $this->result = "Błąd przy ładowaniu helpera: " . $e->getMessage();
            }
        }
    }

    public function html() {
        echo '<h1>' . $this->getLang('admin_title') . '</h1>';
        
        echo '<form action="" method="post" class="aiarticleagent-form">';
        formSecurityToken();
        echo '<label>' . $this->getLang('prompt_label') . '<br/>';
        echo '<textarea name="ai_agent_prompt" rows="5" cols="80"></textarea>';
        echo '</label><br/>';
        echo '<button type="submit" class="button">' . $this->getLang('btn_submit') . '</button>';
        echo '</form>';
        
        if (!empty($this->result)) {
            echo '<h2>Wygenerowany wynik (Kod Wiki):</h2>';
            echo '<textarea rows="20" cols="100" readonly>' . hsc($this->result) . '</textarea>';
        }
    }
}
