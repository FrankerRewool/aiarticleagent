<?php
if(!defined('DOKU_INC')) die();

/**
 * Składnia pozwalająca wygenerować artykuł w miejscu wstawienia.
 * Użycie: {{aiarticle> Temat artykułu | model=gpt-4o | style=formal }}
 */
class syntax_plugin_aiarticleagent extends DokuWiki_Syntax_Plugin {

    public function getType() { return 'substition'; }
    public function getSort() { return 155; }
    
    public function connectTo($mode) {
        $this->Lexer->addSpecialPattern('\{\{aiarticle>.*\}\}', $mode, 'plugin_aiarticleagent');
    }

    public function handle($match, $state, $pos, Doku_Handler $handler) {
        $match = substr($match, 12, -2); // remove {{aiarticle> and }}
        $parts = explode('|', $match);
        $prompt = trim($parts[0]);
        
        $options = [];
        for ($i = 1; $i < count($parts); $i++) {
            $param = explode('=', trim($parts[$i]));
            if (count($param) == 2) {
                $options[trim($param[0])] = trim($param[1]);
            }
        }
        
        return array('prompt' => $prompt, 'options' => $options);
    }

    public function render($mode, Doku_Renderer $renderer, $data) {
        if($mode == 'xhtml'){
            // Zamiast blokować renderowanie i czekać na generowanie w locie (co spowoduje timeout),
            // wstawiamy placeholder i generujemy za pomocą JavaScript/AJAX
            // UWAGA: Ta implementacja to placeholder. Rzeczywiste generowanie w syntax jest podatne 
            // na timeouty PHP przy włączonym buforowaniu strony (chcemy uniknąć podwójnego generowania)
            
            $id = 'ai_agent_uid_' . md5($data['prompt'] . serialize($data['options']) . time());
            $renderer->doc .= '<div id="'.$id.'" class="ai-article-container" data-prompt="'.hsc($data['prompt']).'" data-options="'.hsc(json_encode($data['options'])).'">';
            $renderer->doc .= '<em>[AI Agent: Przygotowywanie treści dla tematu "'.hsc($data['prompt']).'"]</em>';
            $renderer->doc .= ' <button class="ai-generate-btn" onclick="generateAIArticle(\''.$id.'\')">Generuj teraz</button>';
            $renderer->doc .= '</div>';
            return true;
        }
        return false;
    }
}
