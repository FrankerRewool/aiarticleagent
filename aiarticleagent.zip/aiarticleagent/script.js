/**
 * AI Article Agent - JavaScript do obsługi AJAX
 */

// DokuWiki szuka tej funkcji (addBtnAction + NazwaTypu z action.php)
window.addBtnActionAiarticleagent = function($btn, props, edid) {
    $btn.click(function(e) {
        e.preventDefault();
        var promptText = prompt("Wpisz temat, wytyczne lub instrukcje dla Agenta AI:");
        if (!promptText) return;

        var $textArea = jQuery('#' + edid);
        var originalVal = $textArea.val();
        var placeholder = "\n\n[...AI Agent pracuje - czekaj, może to potrwać kilkadziesiąt sekund...]\n\n";
        $textArea.val(originalVal + placeholder);
        
        // Pobranie tokenu bezpieczeństwa
        var token = jQuery('form#dw__editform input[name="sectok"]').val();
        if (!token) {
            token = JSINFO && JSINFO.sectok ? JSINFO.sectok : '';
        }

        jQuery.ajax({
            type: 'POST',
            url: DOKU_BASE + 'lib/exe/ajax.php',
            data: {
                call: 'aiarticleagent_generate',
                custom_prompt: promptText,
                sectok: token
            },
            timeout: 300000, // 5 minut timeout dla długich żądań
            dataType: 'text'
        })
        .done(function(data) {
            var currentVal = $textArea.val();
            $textArea.val(currentVal.replace(placeholder, "\n\n" + data + "\n\n"));
            console.log("AI Article wygenerowany pomyślnie");
        })
        .fail(function(jqXHR, textStatus, errorThrown) {
            console.error("AI Article Error:", textStatus, errorThrown, jqXHR.responseText);
            alert("Błąd: " + textStatus + "\n\n" + jqXHR.responseText);
            var currentVal = $textArea.val();
            $textArea.val(currentVal.replace(placeholder, ""));
        });
    });
};

// Obsługa AJAX w składni (kliknięcie przycisku "Generuj teraz")
window.generateAIArticle = function(containerId) {
    var container = document.getElementById(containerId);
    if (!container) return;
    
    var prompt = container.getAttribute('data-prompt');
    var optionsStr = container.getAttribute('data-options');
    
    container.innerHTML = '<strong>Trwa generowanie (AI Agent)... Proszę czekać.</strong>';
    
    var token = jQuery('form#dw__editform input[name="sectok"]').val();
    if (!token) {
        token = JSINFO && JSINFO.sectok ? JSINFO.sectok : '';
    }

    jQuery.ajax({
        type: 'POST',
        url: DOKU_BASE + 'lib/exe/ajax.php',
        data: {
            call: 'aiarticleagent_generate',
            custom_prompt: prompt,
            options: optionsStr,
            sectok: token
        },
        timeout: 300000,
        dataType: 'text'
    })
    .done(function(data) {
        container.innerHTML = '<pre>' + jQuery('<div/>').text(data).html() + '</pre>';
    })
    .fail(function(jqXHR, textStatus, errorThrown) {
        container.innerHTML = '<strong style="color:red">Błąd (' + textStatus + '): ' + jqXHR.responseText + '</strong>';
    });
};
