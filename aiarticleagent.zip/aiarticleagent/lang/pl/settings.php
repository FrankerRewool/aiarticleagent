<?php
/**
 * Polish language file for settings
 */
$lang['api_provider']  = 'Dostawca API (OpenRouter, OpenAI, Anthropic)';
$lang['api_url']       = 'Adres bazowy API (np. https://openrouter.ai/api/v1/chat/completions)';
$lang['api_key']       = 'Klucz API';
$lang['default_model'] = 'Domyślny model (np. openai/gpt-4o, claude-3-opus)';
$lang['temperature']   = 'Temperatura (0.0 - 2.0, domyślnie 0.7, wyższe wartości = bardziej kreatywne)';
$lang['max_tokens']    = 'Maksymalna liczba tokenów w odpowiedzi';
$lang['system_prompt'] = 'Domyślny System Prompt definiujący styl i zasady zachowania Agenta';
