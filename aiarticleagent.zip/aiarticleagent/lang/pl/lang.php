<?php
/**
 * Polish language file
 */
$lang['btn_generate'] = 'Generuj z AI';
$lang['error_api']    = 'Błąd połączenia z API AI polecenia: %s';
$lang['loading']      = 'Trwa generowanie artykułu... To może potrwać kilka minut.';
$lang['menu']         = 'AI Article Agent - Panel Zarządzania';
$lang['admin_title']  = 'Panel Generowania Artykułów z AI';
$lang['prompt_label'] = 'Podaj temat i instrukcje dla Agenta AI:';
$lang['btn_submit']   = 'Generuj Artykuł';
