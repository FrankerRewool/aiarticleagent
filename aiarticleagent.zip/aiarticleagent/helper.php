<?php
if(!defined('DOKU_INC')) die();

/**
 * Helper plugin dla aiarticleagent
 * Dostarcza wspólną funkcję do komunikacji z API (OpenRouter/OpenAI/Anthropic)
 */
class helper_plugin_aiarticleagent extends DokuWiki_Plugin {

    public function getInfo() {
        return confToHash(dirname(__FILE__).'/plugin.info.txt');
    }

    /**
     * Główna funkcja do generowania artykułu na podstawie promptu.
     * @param string $prompt Temat / zapytanie użytkownika
     * @param array $options Opcjonalne nadpisania (model, temperature, system_prompt)
     * @return string Wygenerowany kod wiki
     */
    public function generateArticle($prompt, $options = []) {
        $apiKey = $this->getConf('api_key');
        if (empty($apiKey)) {
            return "Bład: Brak skonfigurowanego klucza API w panelu administracyjnym.";
        }

        $provider = $this->getConf('api_provider');
        $model = isset($options['model']) ? $options['model'] : $this->getConf('default_model');
        $temperature = isset($options['temperature']) ? (float)$options['temperature'] : (float)$this->getConf('temperature');
        $max_tokens = isset($options['max_tokens']) ? (int)$options['max_tokens'] : (int)$this->getConf('max_tokens');
        $sysPrompt = isset($options['system_prompt']) ? $options['system_prompt'] : $this->getConf('system_prompt');
        $apiUrl = $this->getConf('api_url');

        if (empty($apiUrl)) {
            return "Błąd: Brak URL do API w konfiguracji.";
        }

        // Prepare context
        $messages = [
            ["role" => "system", "content" => $sysPrompt],
            ["role" => "user", "content" => $prompt]
        ];

        $payload = [
            "model" => $model,
            "messages" => $messages,
            "temperature" => $temperature,
            "max_tokens" => $max_tokens
        ];
        
        $jsonPayload = json_encode($payload);

        // Spróbuj cURL najpierw - bardziej niezawodne niż DokuHTTPClient
        if (function_exists('curl_init')) {
            return $this->callAPIViaCurl($apiUrl, $jsonPayload, $apiKey, $provider);
        }

        // Fallback do DokuHTTPClient
        return $this->callAPIViaHTTP($apiUrl, $jsonPayload, $apiKey, $provider);
    }

    /**
     * Wysyła żądanie API za pomocą cURL
     */
    private function callAPIViaCurl($apiUrl, $jsonPayload, $apiKey, $provider) {
        $ch = curl_init($apiUrl);
        
        $headers = [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apiKey
        ];

        if ($provider === 'openrouter') {
            $headers[] = 'HTTP-Referer: ' . (defined('DOKU_URL') ? DOKU_URL : 'http://localhost');
            $headers[] = 'X-Title: DokuWiki AI Article Agent';
        }

        if ($provider === 'anthropic') {
            // Dla Anthropic API
            $headers = array_filter($headers, function($v) { 
                return strpos($v, 'Authorization') === false; 
            });
            $headers[] = 'x-api-key: ' . $apiKey;
            $headers[] = 'anthropic-version: 2023-06-01';
        }

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonPayload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array_values($headers));
        curl_setopt($ch, CURLOPT_TIMEOUT, 180);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            return "Błąd cURL: " . $curlError . " (kod: " . curl_errno($ch) . ")";
        }

        if ($httpCode >= 400) {
            return "Błąd API (HTTP " . $httpCode . "): " . substr($response, 0, 500);
        }

        if (!$response) {
            return "Błąd: Pusta odpowiedź od API.";
        }

        return $this->parseAPIResponse($response);
    }

    /**
     * Wysyła żądanie API za pomocą DokuHTTPClient
     */
    private function callAPIViaHTTP($apiUrl, $jsonPayload, $apiKey, $provider) {
        $http = new dokuwiki\HTTP\DokuHTTPClient();
        $http->timeout = 180;
        $http->headers['Authorization'] = 'Bearer ' . $apiKey;
        $http->headers['Content-Type'] = 'application/json';

        if ($provider === 'openrouter') {
            $http->headers['HTTP-Referer'] = defined('DOKU_URL') ? DOKU_URL : 'http://localhost';
            $http->headers['X-Title'] = 'DokuWiki AI Article Agent';
        }

        if ($provider === 'anthropic') {
            $http->headers['x-api-key'] = $apiKey;
            $http->headers['anthropic-version'] = '2023-06-01';
            unset($http->headers['Authorization']);
        }

        $response = @$http->post($apiUrl, $jsonPayload);

        if (!$response) {
            return "Błąd DokuHTTPClient: " . $http->error . " (Status: " . $http->status . ")";
        }

        return $this->parseAPIResponse($response);
    }

    /**
     * Parsuje odpowiedź API
     */
    private function parseAPIResponse($response) {
        $data = json_decode($response, true);
        
        if (!$data) {
            return "Błąd parsowania JSON: " . substr($response, 0, 300);
        }

        if (isset($data['error'])) {
            if (is_array($data['error'])) {
                return "Błąd API: " . json_encode($data['error']);
            }
            return "Błąd API: " . $data['error'];
        }

        if (isset($data['choices'][0]['message']['content'])) {
            return $data['choices'][0]['message']['content'];
        }

        return "Nieoczekiwany format odpowiedzi API: " . substr($response, 0, 500);
    }
}
