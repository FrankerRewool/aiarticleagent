<?php
if(!defined('DOKU_INC')) die();

/**
 * Action plugin: dodaje przycisk do paska edytora i obsługuje AJAX
 */
class action_plugin_aiarticleagent extends DokuWiki_Action_Plugin {

    public function register(Doku_Event_Handler $controller) {
        // Dodaj przycisk do paska edycji
        $controller->register_hook('TOOLBAR_DEFINE', 'AFTER', $this, 'insert_button');
        
        // Obsługa requesta AJAX z syntax.php lub paska narzędzi
        $controller->register_hook('AJAX_CALL_UNKNOWN', 'BEFORE', $this, 'handle_ajax');
    }

    public function insert_button(Doku_Event $event, $param) {
        $event->data[] = array(
            'type'   => 'aiarticleagent', // Custom type - DokuWiki będzie szukał addBtnActionAiarticleagent
            'title'  => $this->getLang('btn_generate'),
            'icon'   => '../../plugins/aiarticleagent/images/icon.png'
        );
    }

    public function handle_ajax(Doku_Event $event, $param) {
        if ($event->data !== 'aiarticleagent_generate') return;
        $event->preventDefault();
        $event->stopPropagation();

        if(!checkSecurityToken()){
            echo "Błąd CSRF (nieautoryzowane żądanie).";
            return;
        }

        global $INPUT;
        $prompt = $INPUT->str('custom_prompt');
        $optionsRaw = $INPUT->str('options', '{}');
        $options = json_decode($optionsRaw, true);
        if (!is_array($options)) $options = [];

        if (empty($prompt)) {
            echo "Błąd: Brak tematu/promptu.";
            return;
        }

        // Ładowanie helpera - nazwa to aiarticleagent (nazwa pluginu)
        try {
            $helper = plugin_load('helper', 'aiarticleagent');
            if (!$helper) {
                echo "Błąd: Nie można załadować helpera aiarticleagent.";
                return;
            }

            $result = $helper->generateArticle($prompt, $options);
            echo $result;
        } catch (Exception $e) {
            echo "Błąd przy ładowaniu helpera: " . $e->getMessage();
        }
    }
}
