<?php
/**
 * Configuration metadata for the AI Article Agent plugin
 * Defines the types and validation rules for configuration settings
 */

// API provider selection (multichoice dropdown)
$meta['api_provider'] = array('multichoice', '_choices' => array('openrouter', 'openai', 'anthropic', 'custom'));

// API endpoint URL (string)
$meta['api_url'] = array('string');

// API key (password field - hidden from display)
$meta['api_key'] = array('password');

// Default model name (string)
$meta['default_model'] = array('string');

// Temperature setting - float value between 0.0 and 2.0
$meta['temperature'] = array('string');

// Maximum tokens in response (integer)
$meta['max_tokens'] = array('string');

// System prompt - textarea for long text
$meta['system_prompt'] = array('text');
