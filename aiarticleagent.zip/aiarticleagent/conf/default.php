<?php
/**
 * Default settings for the AI Article Agent plugin
 */
$conf['api_provider'] = 'openrouter'; // openrouter, openai, anthropic
$conf['api_url']      = 'https://openrouter.ai/api/v1/chat/completions'; // Default OpenRouter URL
$conf['api_key']      = ''; // Empty by default - must be set by admin
$conf['default_model']= 'openai/gpt-4o'; // Default model
$conf['temperature']  = '0.7'; // Temperature as string (DokuWiki converts to float)
$conf['max_tokens']   = '4000'; // Max tokens as string (DokuWiki converts to int)
$conf['system_prompt']= "Jesteś ekspertem DokuWiki. Wygeneruj artykuł na zadany temat. 
Używaj składni DokuWiki: 
- nagłówki (===== Nagłówek =====)
- listy (* element)
- pogrubienia (**tekst**)
- linki wewnętrzne ([[strona]])
Strukturyzuj odpowiedź. Zbuduj spis treści, wstaw wstęp, rozwinięcie i podsumowanie.";
